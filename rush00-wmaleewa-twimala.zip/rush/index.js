function goToWmaleewa() {
  window.location.href = 'wmaleewa/wmaleewa.html';
}

function goToTwimala() {
  window.location.href = 'twimala/twimala.html';
}